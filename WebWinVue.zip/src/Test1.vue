<script setup lang="ts">
import wininputbox from './components/webwin-inputbox.vue'
import winpasswordbox from './components/webwin-passwordbox.vue'
</script>
<template>
<h2 style="font-weight: normal; margin-top: -2.5px; margin-bottom: 10px">主页</h2>
<p style="font-size: 15px;">欢迎来到Web-Win-Vue的测试页</p>
<wininputbox placeholder="aa" @change='console.log($event.target.value)'/>
<winpasswordbox placeholder="aa" @change='console.log($event.target.value)'/>
</template>
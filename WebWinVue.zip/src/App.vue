<script setup></script>

<template>
  <div style="height: 100%;">
    <router-view style="height: 100%;"></router-view>
  </div>
</template>

<style scoped></style>
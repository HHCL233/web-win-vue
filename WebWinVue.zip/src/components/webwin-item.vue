<template>
  <ul class="side-bar">
    <li
      v-for="(item, idx) in items"
      :key="idx"
      :class="{ active: idx === modelValue }"
      @click="$emit('update:modelValue', idx)"
    >
      <span class="indicator" />

      <svg
        class="icon"
        viewBox="0 0 24 24"
        fill="currentColor"
        aria-hidden="true"
      >
        <path :d="item.icon" />
      </svg>

      <span class="label">{{ item.name }}</span>
    </li>
  </ul>
</template>

<script setup>
console.log(`%c✨Welcome to Web-Win-Vue-Item✨`, "\n  color: #0078d7;\n  text-shadow: 0 1px 0 #0078d7;");
defineProps({
  items: { type: Array, required: true },
  modelValue: { type: Number, default: 0 }
})
defineEmits(['update:modelValue'])
</script>

<style scoped>
.side-bar {
  user-select: none;
  list-style: none;
  margin: 0;
  padding: 0;
  width: var(--sb-width, 220px);
  font-size: var(--sb-fs, 14px);
}

.side-bar li {
  position: relative;
  display: flex;
  align-items: center;
  padding: var(--sb-pad, 10px 16px);
  transition: background 0.2s;
}

.side-bar li:hover {
  background: var(--sb-hover-bg, #f5f5f5);
}

.indicator {
  position: absolute;
  left: 0;
  top: 50%;
  margin-top: -12.5px;
  bottom: 0;
  width: var(--sb-indicator-width, 3px);
  background: var(--sb-indicator-color, #006fd0);
  transform: scaleY(0);
  height: 25px;
  line-height: 100px;
}

.side-bar li.active .indicator {
  transform: scaleY(1);
}

.icon {
  width: var(--sb-icon-size, 20px);
  height: var(--sb-icon-size, 20px);
  margin-right: var(--sb-icon-mr, 12px);
  color: var(--sb-icon-color, #333);
  flex-shrink: 0;
}

.label {
  color: var(--sb-label-color, #333);
  white-space: nowrap;
}

</style>